package com.example.paysync

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
