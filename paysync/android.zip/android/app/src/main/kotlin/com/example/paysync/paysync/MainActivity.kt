package com.example.paysync.paysync

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
