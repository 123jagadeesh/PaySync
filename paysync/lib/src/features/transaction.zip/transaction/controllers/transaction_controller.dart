import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class TransactionController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final RxList<TransactionModel> transactions = <TransactionModel>[].obs;
  final RxBool isLoading = false.obs;

 Future<void> addTransaction({
  required double amount,
  required String category,
  required String paymentMethod,
  required DateTime dateTime,
  String? notes,
  XFile? receiptImage,
  GeoPoint? location,
  required String userId,
}) async {
  try {
    isLoading.value = true;
    print("addTransaction called");

    String? receiptUrl;

    if (receiptImage != null) {
      print("Uploading image...");
      final file = File(receiptImage.path);
      final ref = _storage.ref().child('receipts/$userId/${DateTime.now().millisecondsSinceEpoch}');
      await ref.putFile(file);
      receiptUrl = await ref.getDownloadURL();
      print("Image uploaded. URL: $receiptUrl");
    }

    print("Creating transaction object...");
    final docRef = _firestore.collection('transactions').doc();
    final transaction = TransactionModel.create(
      id: docRef.id,
      amount: amount,
      category: category,
      paymentMethod: paymentMethod,
      dateTime: dateTime,
      notes: notes,
      receiptUrl: receiptUrl,
      location: location,
      userId: userId,
    );
    print("Saving to Firestore...");
    await docRef.set(transaction.toMap());

    print("Reloading transactions...");
    await loadTransactions(userId);

    print("Showing snackbar...");
    Get.snackbar(
      'Success',
      'Transaction added successfully',
      snackPosition: SnackPosition.BOTTOM,
    );
  } catch (e) {
    print('Error adding transaction: $e');
    Get.snackbar(
      'Error',
      'Failed to add transaction: $e',
      snackPosition: SnackPosition.BOTTOM,
    );
  } finally {
    isLoading.value = false;
  }
}


  Future<void> loadTransactions(String userId) async {
    try {
      isLoading.value = true;
      final snapshot = await _firestore
          .collection('transactions')
          .where('userId', isEqualTo: userId)
          .orderBy('dateTime', descending: true)
          .get();

      transactions.value = snapshot.docs
          .map((doc) => TransactionModel.fromMap(doc.data())).cast<TransactionModel>()
          .toList();
    } catch (e) {
      print('Error loading transactions: $e');
      Get.snackbar(
        'Error',
        'Failed to load transactions: $e',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  TransactionModel? getTransactionById(String id) {
      return transactions.firstWhereOrNull((t) => t.id == id);
    }
  
    Future<void> deleteTransaction(String id) async {
      try {
        await _firestore.collection('transactions').doc(id).delete();
        transactions.removeWhere((t) => t.id == id);
        Get.snackbar('Success', 'Transaction deleted successfully');
      } catch (e) {
        Get.snackbar('Error', 'Failed to delete transaction: $e');
      }
    }
}

mixin TransactionModel {
  String? get category => null;

  DateTime? get dateTime => null;

  get amount => null;
  
  get id => null;

  get paymentMethod => null;

  get notes => null;

  get receiptUrl => null;

  get location => null;
  
  static Future<void> fromMap(Map<String, dynamic> data) async {}
  
  Map<String, dynamic> toMap() {
    return {
      'category': category,
      'dateTime': dateTime?.toIso8601String(),
      'amount': amount,
    };
  }
  
  static create({required String id, required double amount, required String category, required String paymentMethod, required DateTime dateTime, String? notes, String? receiptUrl, GeoPoint? location, required String userId}) {}
}