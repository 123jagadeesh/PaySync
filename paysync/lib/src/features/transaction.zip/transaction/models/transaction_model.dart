import 'package:cloud_firestore/cloud_firestore.dart';

class TransactionModel {
  final String id;
  final double amount;
  final String category;
  final String paymentMethod;
  final DateTime dateTime;
  final String? notes;
  final String? receiptUrl;
  final String? location;
  final String userId;

  TransactionModel({
    required this.id,
    required this.amount,
    required this.category,
    required this.paymentMethod,
    required this.dateTime,
    this.notes,
    this.receiptUrl,
    this.location,
    required this.userId,
  });

  factory TransactionModel.fromMap(Map<String, dynamic> data) {
    return TransactionModel(
      id: data['id'],
      amount: data['amount']?.toDouble() ?? 0.0,
      category: data['category'] ?? '',
      paymentMethod: data['paymentMethod'] ?? '',
      dateTime: DateTime.parse(data['dateTime']),
      notes: data['notes'],
      receiptUrl: data['receiptUrl'],
      location: data['location'],
      userId: data['userId'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'amount': amount,
      'category': category,
      'paymentMethod': paymentMethod,
      'dateTime': dateTime.toIso8601String(),
      'notes': notes,
      'receiptUrl': receiptUrl,
      'location': location,
      'userId': userId,
    };
  }

  static TransactionModel create({
    required String id,
    required double amount,
    required String category,
    required String paymentMethod,
    required DateTime dateTime,
    String? notes,
    String? receiptUrl,
    String? location,
    required String userId,
  }) {
    return TransactionModel(
      id: id,
      amount: amount,
      category: category,
      paymentMethod: paymentMethod,
      dateTime: dateTime,
      notes: notes,
      receiptUrl: receiptUrl,
      location: location,
      userId: userId,
    );
  }
}
