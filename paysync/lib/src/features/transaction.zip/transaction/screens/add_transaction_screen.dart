import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:paysync/src/features/authentication/controllers/auth_controller.dart';
import 'package:paysync/src/features/transaction/controllers/transaction_controller.dart';
import 'package:paysync/src/features/transaction/screens/map_screen.dart';

class AddTransactionScreen extends StatefulWidget {
  const AddTransactionScreen({super.key});

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _notesController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  String? _selectedCategory;
  String? _selectedPaymentMethod;
  XFile? _receiptImage;
  LatLng? _selectedLocation;

  final List<String> _categories = [
    'Food',
    'Travel',
    'Bills',
    'Shopping',
    'Entertainment',
    'Others'
  ];

  final List<String> _paymentMethods = [
    'Cash',
    'UPI',
    'Card',
    'Bank Transfer'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Transaction'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Amount Input
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Amount (₹)',
                  prefixIcon: Icon(Icons.currency_rupee),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an amount';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Category Dropdown
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  prefixIcon: Icon(Icons.category),
                ),
                items: _categories.map((String category) {
                  return DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _selectedCategory = value;
                  });
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select a category';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Payment Method Dropdown
              DropdownButtonFormField<String>(
                value: _selectedPaymentMethod,
                decoration: const InputDecoration(
                  labelText: 'Payment Method',
                  prefixIcon: Icon(Icons.payment),
                ),
                items: _paymentMethods.map((String method) {
                  return DropdownMenuItem(
                    value: method,
                    child: Text(method),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _selectedPaymentMethod = value;
                  });
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select a payment method';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Date Picker
              ListTile(
                leading: const Icon(Icons.calendar_today),
                title: Text(
                  'Date: ${DateFormat('dd/MM/yyyy').format(_selectedDate)}',
                ),
                onTap: () async {
                  final DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: _selectedDate,
                    firstDate: DateTime(2000),
                    lastDate: DateTime.now(),
                  );
                  if (picked != null) {
                    setState(() {
                      _selectedDate = picked;
                    });
                  }
                },
              ),

              // Time Picker
              ListTile(
                leading: const Icon(Icons.access_time),
                title: Text(
                  'Time: ${_selectedTime.format(context)}',
                ),
                onTap: () async {
                  final TimeOfDay? picked = await showTimePicker(
                    context: context,
                    initialTime: _selectedTime,
                  );
                  if (picked != null) {
                    setState(() {
                      _selectedTime = picked;
                    });
                  }
                },
              ),

              // Notes Field
              TextFormField(
                controller: _notesController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Notes (Optional)',
                  prefixIcon: Icon(Icons.note),
                ),
              ),
              const SizedBox(height: 16),

              // Image Upload Button
              ElevatedButton.icon(
                onPressed: () async {
                  final ImagePicker picker = ImagePicker();
                  final XFile? image = await picker.pickImage(
                    source: ImageSource.gallery,
                  );
                  if (image != null) {
                    setState(() {
                      _receiptImage = image;
                    });
                  }
                },
                icon: const Icon(Icons.image),
                label: Text(_receiptImage == null 
                  ? 'Add Receipt Image' 
                  : 'Receipt Added'),
              ),
              const SizedBox(height: 16),

              // Location Button
              ElevatedButton.icon(
                onPressed: () async {
                  final result = await Get.to(() => MapScreen());
                  if (result != null && result is LatLng) {
                    setState(() {
                      _selectedLocation = result;
                    });
                  }
                },
                icon: const Icon(Icons.location_on),
                label: Text(_selectedLocation == null 
                  ? 'Add Location' 
                  : 'Location: ${_selectedLocation!.latitude.toStringAsFixed(2)}, ${_selectedLocation!.longitude.toStringAsFixed(2)}'),
              ),
              const SizedBox(height: 24),

              // Save Button
              ElevatedButton(
                onPressed: _saveTransaction,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.all(16),
                ),
                child: const Text('Save Transaction'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Add in the class
  final transactionController = Get.find<TransactionController>();
  final authController = Get.find<AuthController>();

  void _saveTransaction() async {
    if (_formKey.currentState!.validate()) {
      final currentUser = authController.firebaseUser.value;  // Update this line
      if (currentUser == null) {
        Get.snackbar(
          'Error',
          'Please login to add transactions',
          snackPosition: SnackPosition.BOTTOM,
        );
        return;
      }

      try {
        await transactionController.addTransaction(
          amount: double.parse(_amountController.text),
          category: _selectedCategory!,
          paymentMethod: _selectedPaymentMethod!,
          dateTime: DateTime(
            _selectedDate.year,
            _selectedDate.month,
            _selectedDate.day,
            _selectedTime.hour,
            _selectedTime.minute,
          ),
          notes: _notesController.text,
          receiptImage: _receiptImage,
          location: _selectedLocation != null 
            ? GeoPoint(_selectedLocation!.latitude, _selectedLocation!.longitude)
            : null,
          userId: currentUser.uid,
        );
        Get.back();
      } catch (e) {
        Get.snackbar('Error', 'Failed to save transaction: $e');
      }
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}

// ignore: camel_case_types

