import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:paysync/src/features/transaction/controllers/transaction_controller.dart';

class TransactionDetailsScreen extends StatelessWidget {
  const TransactionDetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final transactionController = Get.find<TransactionController>();
    final String transactionId = Get.parameters['id'] ?? '';
    final transaction = transactionController.getTransactionById(transactionId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              // TODO: Implement edit functionality
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () {
              _showDeleteConfirmation(context, transactionController, transactionId);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Amount Section
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      '₹${transaction?.amount}',
                      style: Theme.of(context).textTheme.headlineLarge,
                    ),
                    Text(
                      transaction?.category ?? 'No Category',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Date and Payment Method
            Card(
              child: ListTile(
                leading: const Icon(Icons.calendar_today),
                title: Text(
                  DateFormat('dd MMM yyyy, hh:mm a').format(transaction?.dateTime ?? DateTime.now()),
                ),
                subtitle: Text('Paid via ${transaction?.paymentMethod}'),
              ),
            ),
            const SizedBox(height: 16),

            // Notes
            if (transaction?.notes != null && transaction?.notes!.isNotEmpty)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.note),
                  title: const Text('Notes'),
                  subtitle: Text(transaction?.notes!),
                ),
              ),
            const SizedBox(height: 16),

            // Receipt Image
            if (transaction?.receiptUrl != null)
              Card(
                child: Column(
                  children: [
                    Image.network(
                      transaction?.receiptUrl!,
                      height: 200,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                    ButtonBar(
                      children: [
                        TextButton.icon(
                          icon: const Icon(Icons.download),
                          label: const Text('Download'),
                          onPressed: () {
                            // TODO: Implement download functionality
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 16),

            // Location Map
            if (transaction?.location != null)
              Card(
                child: SizedBox(
                  height: 200,
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: LatLng(
                        transaction?.location!.latitude,
                        transaction?.location!.longitude,
                      ),
                      zoom: 15,
                    ),
                    markers: {
                      Marker(
                        markerId: const MarkerId('transaction_location'),
                        position: LatLng(
                          transaction?.location!.latitude,
                          transaction?.location!.longitude,
                        ),
                      ),
                    },
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmation(BuildContext context, TransactionController controller, String transactionId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Transaction'),
        content: const Text('Are you sure you want to delete this transaction?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              await controller.deleteTransaction(transactionId);
              Get.back();
              Get.back();
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}